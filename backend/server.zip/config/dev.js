module.exports = {
  mongoURI:
    "mongodb+srv://bobby:bobby@esotericsocial-bhe06.mongodb.net/test?retryWrites=true",
  secret: "asdfasdfasdfasdfasdflklkj"
};
